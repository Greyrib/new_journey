Du vågner efter den vildeste JBro-dag på UCL og videre ind i Odense, i din brændert er du havnet på en ø som du aldrig
har set før, efter at havet kastet den sidste kasse øl op igen,
 står du op og kommer i tanke om at du skal afleverer dit Budweg
project, så du må heller' se at finde en vej hjem. og nåååååh jaaaaah du skal hjælpe din kæreste med at flytte, ups.
